// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XACTIVATION_ACCELERATOR_H
#define XACTIVATION_ACCELERATOR_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xactivation_accelerator_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XActivation_accelerator_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XActivation_accelerator;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XActivation_accelerator_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XActivation_accelerator_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XActivation_accelerator_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XActivation_accelerator_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XActivation_accelerator_Initialize(XActivation_accelerator *InstancePtr, u16 DeviceId);
XActivation_accelerator_Config* XActivation_accelerator_LookupConfig(u16 DeviceId);
int XActivation_accelerator_CfgInitialize(XActivation_accelerator *InstancePtr, XActivation_accelerator_Config *ConfigPtr);
#else
int XActivation_accelerator_Initialize(XActivation_accelerator *InstancePtr, const char* InstanceName);
int XActivation_accelerator_Release(XActivation_accelerator *InstancePtr);
#endif

void XActivation_accelerator_Start(XActivation_accelerator *InstancePtr);
u32 XActivation_accelerator_IsDone(XActivation_accelerator *InstancePtr);
u32 XActivation_accelerator_IsIdle(XActivation_accelerator *InstancePtr);
u32 XActivation_accelerator_IsReady(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_EnableAutoRestart(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_DisableAutoRestart(XActivation_accelerator *InstancePtr);

void XActivation_accelerator_Set_in0(XActivation_accelerator *InstancePtr, u64 Data);
u64 XActivation_accelerator_Get_in0(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_Set_in1(XActivation_accelerator *InstancePtr, u64 Data);
u64 XActivation_accelerator_Get_in1(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_Set_out_r(XActivation_accelerator *InstancePtr, u64 Data);
u64 XActivation_accelerator_Get_out_r(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_Set_stage(XActivation_accelerator *InstancePtr, u32 Data);
u32 XActivation_accelerator_Get_stage(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_Set_config_r(XActivation_accelerator *InstancePtr, u32 Data);
u32 XActivation_accelerator_Get_config_r(XActivation_accelerator *InstancePtr);

void XActivation_accelerator_InterruptGlobalEnable(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_InterruptGlobalDisable(XActivation_accelerator *InstancePtr);
void XActivation_accelerator_InterruptEnable(XActivation_accelerator *InstancePtr, u32 Mask);
void XActivation_accelerator_InterruptDisable(XActivation_accelerator *InstancePtr, u32 Mask);
void XActivation_accelerator_InterruptClear(XActivation_accelerator *InstancePtr, u32 Mask);
u32 XActivation_accelerator_InterruptGetEnabled(XActivation_accelerator *InstancePtr);
u32 XActivation_accelerator_InterruptGetStatus(XActivation_accelerator *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
